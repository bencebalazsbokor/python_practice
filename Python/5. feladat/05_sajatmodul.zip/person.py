#!/usr/bin/env python
# coding: utf-8

# In[1]:


class Person():
    def __init__(self, name):
        self.name = name
        
class Student(Person):
    def __init__(self, name):
        Person.__init__(self, name)
        self.grades = []

    def add_grade(self, grade):
        self.grades.append(grade)
        
    def mean(self):
        if self.grades:
            return sum(self.grades) / len(self.grades)

