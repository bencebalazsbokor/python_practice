#!/usr/bin/env python
# coding: utf-8

# In[4]:


import maximum as mx

def display_maximum(a, b, c):
    m = mx.maximum(a, b, c)
    print(f"Az alábbi számok közül:\n{a} {b} {c}\nA legnagyobb érték:\n{m}")

