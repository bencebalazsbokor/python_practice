#!/usr/bin/env python
# coding: utf-8

# In[5]:


from datetime import datetime, timedelta

class Datumkezelo():
    def __init__(self, date_string):
        try:
            self.date = datetime.strptime(date_string, "%Y-%m-%d")
        except ValueError:
            print("A dátumot yyyy-mm-dd formátumban kell megadni.")

    def megjelenit(self):
        print('Dátum: {:}'.format(self.date))

    def hozzaad_nap(self, nap):
        try:
            self.date = self.date + timedelta(days = nap)
        except TypeError:
            print('A megadott napok száma egész típusú kell legyen')

