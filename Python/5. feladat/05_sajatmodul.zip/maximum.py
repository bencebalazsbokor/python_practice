#!/usr/bin/env python
# coding: utf-8

# In[3]:


def maximum(a, b, c):
    max = a
    if(b > max):
        max = b
    elif(c > max):
        max = c
    return max

if __name__ == "__main__":
    a = 7
    b = 6
    c = 9
    m = maximum(a, b, c)
    print(m)
    
    print(maximum(5, 7, 3))

